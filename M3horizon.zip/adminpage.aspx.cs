﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml.Linq;

namespace M3horizon
{
    public partial class adminpage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            LoadClubsandStadium();
            LoadFan();
        }

        protected void Addnewclub(object sender, EventArgs e)
        {
            String cname = newclubname.Text;
            String clocation = newclublocation.Text;

            String connstr = WebConfigurationManager.ConnectionStrings["mydatabase"].ToString();
            SqlConnection connection = new SqlConnection(connstr);

            String query = "select name from Club where name='"+cname+"'";
            SqlDataAdapter sqlDA = new SqlDataAdapter(query,connection);
            DataTable dt = new DataTable();
            connection.Open();
            sqlDA.Fill(dt);
            connection.Close();

            if (dt.Rows.Count > 0)
            {
                caeLabel.Text = "This club already exists :(";
            }
            else
            {
                if (!(cname == "" || clocation == ""))
                {

                    SqlCommand addclub = new SqlCommand("addClub", connection);
                    addclub.CommandType = CommandType.StoredProcedure;

                    addclub.Parameters.Add(new SqlParameter("@clubname", cname));
                    addclub.Parameters.Add(new SqlParameter("@clublocation", clocation));

                    connection.Open();
                    addclub.ExecuteNonQuery();
                    connection.Close();

                    ////("CLUB ADDED or NOT message");
                }
                caeLabel.Text = "";
            }

            LoadClubsandStadium();
        }

        protected void Deleteclub(object sender, EventArgs e)
        {
            String cname = deleteclubname.Text;

            String connstr = WebConfigurationManager.ConnectionStrings["mydatabase"].ToString();
            SqlConnection connection = new SqlConnection(connstr);

            String query = "select name from Club where name='" + cname + "'";
            SqlDataAdapter sqlDA = new SqlDataAdapter(query, connection);
            DataTable dt = new DataTable();
            connection.Open();
            sqlDA.Fill(dt);
            connection.Close();

            if (dt.Rows.Count == 0)
            {
                cdneLabel.Text = "This club does NOT exist";
            }
            else
            {
                if (!(cname == ""))
                {

                    SqlCommand dltclub = new SqlCommand("deleteClub", connection);
                    dltclub.CommandType = CommandType.StoredProcedure;

                    dltclub.Parameters.Add(new SqlParameter("@clubname", cname));

                    connection.Open();
                    dltclub.ExecuteNonQuery();
                    connection.Close();
                }
                cdneLabel.Text = "";
            }

            LoadClubsandStadium();
        }

        protected void Addnewstadium(object sender, EventArgs e)
        {
            String sname = newstadiumname.Text;
            String slocation = newstadiumlocation.Text;
            String scapacity = newstadiumcapacity.Text;
            Boolean flag = true;
            int stadcap;

            String connstr = WebConfigurationManager.ConnectionStrings["mydatabase"].ToString();
            SqlConnection connection = new SqlConnection(connstr);

            String query = "select name from Stadium where name='" + sname + "'";
            SqlDataAdapter sqlDA = new SqlDataAdapter(query, connection);
            DataTable dt = new DataTable();

            connection.Open();
            sqlDA.Fill(dt);



            if (dt.Rows.Count > 0)
            {
                sflagLabel.Text = "This Stadium already exists :(";
                flag = false;
            }
            else
            {
                if (!Int32.TryParse(scapacity,out stadcap))
                {
                    flag = false;
                    sflagLabel.Text = "Please write a number for Capacity";
                }
                else
                {
                    sflagLabel.Text = "";
                }
            }
            
            
            if ( !(sname=="" || slocation=="" || scapacity=="") && flag==true)
            {

                SqlCommand addstadium = new SqlCommand("addStadium", connection);
                addstadium.CommandType = CommandType.StoredProcedure;

                addstadium.Parameters.Add(new SqlParameter("@StadiumName", sname));
                addstadium.Parameters.Add(new SqlParameter("@StadiumLocation", slocation));
                addstadium.Parameters.Add(new SqlParameter("@capacity", scapacity));

                addstadium.ExecuteNonQuery();
            }

            connection.Close();
            LoadClubsandStadium();
        }

        protected void Deletestadium(object sender, EventArgs e)
        {
            String sname = deletestadiumname.Text;

            String connstr = WebConfigurationManager.ConnectionStrings["mydatabase"].ToString();
            SqlConnection connection = new SqlConnection(connstr);

            String query = "select name from Stadium where name='" + sname + "'";
            SqlDataAdapter sqlDA = new SqlDataAdapter(query, connection);
            DataTable dt = new DataTable();
            connection.Open();
            sqlDA.Fill(dt);
            connection.Close();

            if (dt.Rows.Count == 0)
            {
                sdneLabel.Text = "This Stadium does NOT exist";
            }
            else
            {
                if ( !(sname=="") )
                {
                    SqlCommand dltstad = new SqlCommand("deleteStadium", connection);
                    dltstad.CommandType = CommandType.StoredProcedure;

                    dltstad.Parameters.Add(new SqlParameter("@StadiumName", sname));

                    connection.Open();
                    dltstad.ExecuteNonQuery();
                    connection.Close();
                }
                sdneLabel.Text = "";
            }
            LoadClubsandStadium();
        }

        protected void Blockfan(object sender, EventArgs e)
        {
            String id = fannatid1.Text;
            Boolean flag = true;
            int fanid;

            if (!Int32.TryParse(id, out fanid))
            {
                flag = false;
                fflagLabel1.Text = "Fan National ID must be numbers only";
            }
            else
            {
                fflagLabel1.Text = "";
            }

            if ( !(id == "") && flag==true)
            {
                String connstr = WebConfigurationManager.ConnectionStrings["mydatabase"].ToString();
                SqlConnection connection = new SqlConnection(connstr);

                SqlCommand blkfan = new SqlCommand("blockFan", connection);
                blkfan.CommandType = CommandType.StoredProcedure;

                blkfan.Parameters.Add(new SqlParameter("@fanNationalID", fanid));

                connection.Open();
                blkfan.ExecuteNonQuery();
                connection.Close();
            }
            LoadFan();
        }

        protected void Unblockfan(object sender, EventArgs e)
        {
            String id = fannatid2.Text;
            Boolean flag = true;
            int fanid;

            if (!Int32.TryParse(id, out fanid))
            {
                flag = false;
                fflagLabel2.Text = "Fan National ID must be numbers only";
            }
            else
            {
                fflagLabel2.Text = "";
            }

            if (!(id == "") && flag == true)
            {
                String connstr = WebConfigurationManager.ConnectionStrings["mydatabase"].ToString();
                SqlConnection connection = new SqlConnection(connstr);

                SqlCommand blkfan = new SqlCommand("unblockFan", connection);
                blkfan.CommandType = CommandType.StoredProcedure;

                blkfan.Parameters.Add(new SqlParameter("@fanNationalID", fanid));

                connection.Open();
                blkfan.ExecuteNonQuery();
                connection.Close();
            }
            LoadFan();
        }

        protected void LoadClubsandStadium()
        {
            String connstr = WebConfigurationManager.ConnectionStrings["mydatabase"].ToString();
            SqlConnection connection = new SqlConnection(connstr);
            connection.Open();

            String queryClubs = "select name as Club_Name,location as Location from Club";
            SqlDataAdapter clubDA = new SqlDataAdapter(queryClubs,connection);
            DataTable clubDT = new DataTable();
            clubDA.Fill(clubDT);
            if (clubDT.Rows.Count>0)
            {
                clubGrid.DataSource = clubDT;
                clubGrid.DataBind();
                clubLabel.Text = "";
            }
            else
            {
                clubGrid.DataSource = "";
                clubGrid.DataBind();
                clubLabel.Text = "No Clubs Available";
            }

            String queryStadiums = "select name as Stadium_Name,location as Location,capacity as Capacity from Stadium";
            SqlDataAdapter stadiumDA = new SqlDataAdapter(queryStadiums, connection);
            DataTable stadiumDT = new DataTable();
            stadiumDA.Fill(stadiumDT);
            if (stadiumDT.Rows.Count > 0)
            {
                stadiumGrid.DataSource = stadiumDT;
                stadiumGrid.DataBind();
                stadiumLabel.Text = "";
            }
            else
            {
                stadiumGrid.DataSource = "";
                stadiumGrid.DataBind();
                stadiumLabel.Text = "No Stadiums Available";
            }
            connection.Close();
        }

        protected void LoadFan()
        {

            String connstr = WebConfigurationManager.ConnectionStrings["mydatabase"].ToString();
            SqlConnection connection = new SqlConnection(connstr);
            connection.Open();

            String queryFan = "select national_ID as National_ID,status as Status from Fan";
            SqlDataAdapter fanDA = new SqlDataAdapter(queryFan, connection);
            DataTable fanDT = new DataTable();
            fanDA.Fill(fanDT);

            if(fanDT.Rows.Count > 0)
            {
                fanGrid.DataSource = fanDT;
                fanGrid.DataBind();
                fanLabel.Text = "";
            }
            else
            {
                fanGrid.DataSource = "";
                fanGrid.DataBind();
                fanLabel.Text = "No fans registered";
            }

            connection.Close();
        }

    }
}