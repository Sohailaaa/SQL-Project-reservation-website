﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Security.Cryptography;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml.Linq;

namespace M3horizon
{
    public partial class fan : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //Response.Write("Hello welcome fan: "+Session["currentuser"]);

            String fanusername = (String)Session["currentuser"];
            //String fanusername = "mementos";
            fanusernameLabel.Text = "Fan Username: "+ fanusername;


            String connstr = WebConfigurationManager.ConnectionStrings["mydatabase"].ToString();
            SqlConnection connection = new SqlConnection(connstr);
            connection.Open();

            String fanquery = "select national_ID from Fan where username='" + fanusername + "' ";
            SqlCommand fanCMD = new SqlCommand(fanquery, connection);
            var c = (String)(fanCMD.ExecuteScalar().ToString());
            int FANID = Int32.Parse(c.ToString());

            connection.Close();

            UpcomingFanMatches(FANID);
        }

        protected void AvaialableMatches(object sender, EventArgs e)
        {
            if (hour.Text == "" && min.Text == "")
            {
                String thedate = yyyy.Text + "-" + mm.Text + "-" + dd.Text;
                DateTime newdt;
                if(DateTime.TryParse(thedate,out newdt))
                {
                    dtLabel.Text = "";
                    //display ba2a
                    String connstr = WebConfigurationManager.ConnectionStrings["mydatabase"].ToString();
                    SqlConnection connection = new SqlConnection(connstr);
                    connection.Open();

                    String query = "select distinct m.match_ID as MatchID, c1.name as HostClub ,c2.name as GuestClub ,m.start_time as StartTime, m.end_time as EndTime,s.name as Stadium,s.location as Location,count(t.ID) as Avaialble_number_of_Tickets\r\nfrom match m inner join Club c1 on m.host_club_ID=c1.club_ID\r\n\t\t\t inner join Club c2 on m.guest_club_ID=c2.club_ID\r\n\t\t\t inner join Stadium s on m.stadium_ID=s.ID\r\n\t\t\t inner join Ticket t on m.match_ID=t.match_ID\r\nwhere m.start_time>'" + newdt + "' and t.status=1\r\ngroup by m.match_ID,c1.name,c2.name,m.start_time,m.end_time,s.name,s.location\r\norder by m.start_time";
                    SqlDataAdapter sqlDA = new SqlDataAdapter(query, connection);
                    DataTable dt = new DataTable();
                    sqlDA.Fill(dt);

                    if (dt.Rows.Count > 0)
                    {
                        matchGrid.DataSource = dt;
                        matchGrid.DataBind();
                        nomatchlabel.Text = "";
                        dtLabel.Text = "";
                    }
                    else
                    {
                        matchGrid.DataSource = "";
                        matchGrid.DataBind();
                        nomatchlabel.Text = "No matches are available starting at this time  " + newdt;
                    }

                    connection.Close();
                }
                else
                {
                    matchGrid.DataSource = "";
                    matchGrid.DataBind();
                    dtLabel.Text = "Invalid Date";
                }
            }
            else
            {
                String thedate = yyyy.Text + "-" + mm.Text + "-" + dd.Text + " " + hour.Text + ":" + min.Text;
                DateTime newdt;
                if(DateTime.TryParse(thedate,out newdt))
                {
                    dtLabel.Text = "";
                    //display ba2a
                    String connstr = WebConfigurationManager.ConnectionStrings["mydatabase"].ToString();
                    SqlConnection connection = new SqlConnection(connstr);
                    connection.Open();

                    String query = "select distinct m.match_ID as MatchID, c1.name as HostClub ,c2.name as GuestClub ,m.start_time as StartTime, m.end_time as EndTime,s.name as Stadium,s.location as Location,count(t.ID) as Available_Tickets\r\nfrom match m inner join Club c1 on m.host_club_ID=c1.club_ID\r\n\t\t\t inner join Club c2 on m.guest_club_ID=c2.club_ID\r\n\t\t\t inner join Stadium s on m.stadium_ID=s.ID\r\n\t\t\t inner join Ticket t on m.match_ID=t.match_ID\r\nwhere m.start_time>'" + newdt + "' and t.status=1\r\ngroup by m.match_ID,c1.name,c2.name,m.start_time,m.end_time,s.name,s.location\r\norder by m.start_time";
                    SqlDataAdapter sqlDA = new SqlDataAdapter(query, connection);
                    DataTable dt = new DataTable();
                    sqlDA.Fill(dt);

                    if (dt.Rows.Count > 0)
                    {
                        matchGrid.DataSource = dt;
                        matchGrid.DataBind();
                        nomatchlabel.Text = "";
                        dtLabel.Text = "";
                    }
                    else
                    {
                        matchGrid.DataSource = "";
                        matchGrid.DataBind();
                        nomatchlabel.Text = "No matches are available starting at this time  " + newdt;
                    }

                    connection.Close();
                }
                else
                {
                    dtLabel.Text = "Invalid Date";
                }
            }
        }

        protected void NOWMatches(object sender, EventArgs e)
        {
            String connstr = WebConfigurationManager.ConnectionStrings["mydatabase"].ToString();
            SqlConnection connection = new SqlConnection(connstr);
            connection.Open();

            String query = "select distinct m.match_ID as MatchID, c1.name as HostClub ,c2.name as GuestClub ,m.start_time as StartTime, m.end_time as EndTime,s.name as Stadium,s.location as Location,count(t.ID) as Available_Tickets\r\nfrom match m inner join Club c1 on m.host_club_ID=c1.club_ID\r\n\t\t\t inner join Club c2 on m.guest_club_ID=c2.club_ID\r\n\t\t\t inner join Stadium s on m.stadium_ID=s.ID\r\n\t\t\t inner join Ticket t on m.match_ID=t.match_ID\r\nwhere m.start_time>CURRENT_TIMESTAMP and t.status=1\r\ngroup by m.match_ID,c1.name,c2.name,m.start_time,m.end_time,s.name,s.location\r\norder by m.start_time";
            SqlDataAdapter sqlDA = new SqlDataAdapter(query,connection);
            DataTable dt = new DataTable();
            sqlDA.Fill(dt);

            if (dt.Rows.Count > 0)
            {
                matchGrid.DataSource = dt;
                matchGrid.DataBind();
                nomatchlabel.Text = "";
                dtLabel.Text = "";
            }
            else
            {
                matchGrid.DataSource = "";
                matchGrid.DataBind();
                nomatchlabel.Text = "No matches are available starting at this time  "+DateTime.Now;
                dtLabel.Text = "";
            }

            connection.Close();
        }

        protected void PurchaseTicket(object sender, EventArgs e)
        {
            String fanusername = (String)Session["currentuser"];
            String input = matchIDtextbox.Text;
            //if fan status = blocked then dont allow them to buy tickets
            String connstr = WebConfigurationManager.ConnectionStrings["mydatabase"].ToString();
            SqlConnection connection = new SqlConnection(connstr);
            connection.Open();
            String q1 = "select status from Fan where username='"+fanusername+"' ";
            SqlCommand cmd1 = new SqlCommand(q1,connection);
            Boolean fanstatus = (Boolean)cmd1.ExecuteScalar();
            connection.Close();
            if (fanstatus==false)
            {
                midLabel.Text = "You are blocked from the system and can't purchase any tickets";
            }
            else if (input == "")
            {
                midLabel.Text = "Please enter the MatchID";
            }
            else
            {
                midLabel.Text = "";
                short MID;
                if (Int16.TryParse(input, out MID))
                {
                    connection.Open();
                    //match exists
                    //has tickets
                    String query = "select distinct m.match_ID \r\nfrom match m inner join Club c1 on m.host_club_ID=c1.club_ID\r\n\t\t\t inner join Club c2 on m.guest_club_ID=c2.club_ID\r\n\t\t\t inner join Stadium s on m.stadium_ID=s.ID\r\n\t\t\t inner join Ticket t on m.match_ID=t.match_ID\r\nwhere t.status=1 and m.match_ID='"+MID+"'";
                    SqlDataAdapter sqlDA = new SqlDataAdapter(query,connection);

                    DataTable dt = new DataTable();
                    sqlDA.Fill(dt);

                    if (dt.Rows.Count > 0)
                    {
                        //get fan national ID to buy ticket
                        String fanquery = "select national_ID from Fan where username='" + fanusername + "' ";
                        SqlCommand fanCMD = new SqlCommand(fanquery,connection);
                        var c = (String)(fanCMD.ExecuteScalar().ToString());
                        int FANID = Int32.Parse(c.ToString());

                        //set ticket status=1 and add TicketBuyingTransaction
                        String TTBSquery = "declare @tid int\r\nselect top 1 @tid=ID from ticket where match_ID='"+MID+"' and status=1\r\nprint @tid\r\nupdate Ticket\r\nset status=0\r\nwhere ID=@tid\r\ninsert into TicketBuyingTransaction values ('"+FANID+"',@tid)";
                        SqlCommand addTTBS = new SqlCommand(TTBSquery, connection);
                        addTTBS.ExecuteNonQuery();

                        midLabel.Text = "Ticket Purchased successfully";

                        UpcomingFanMatches(FANID);
                    }
                    else
                    {
                        midLabel.Text = "This match either does not exist or does not have any tickets";
                    }


                    connection.Close();
                    
                }
                else
                {
                    midLabel.Text = "Please enter a valid MatchID as number";
                }
            }

        }

        protected void UpcomingFanMatches(int FANID)
        {
            //call after ticketpurhcase 
            String connstr = WebConfigurationManager.ConnectionStrings["mydatabase"].ToString();
            SqlConnection connection = new SqlConnection(connstr);
            connection.Open();

            String query = "select distinct m.match_ID as MatchID,c1.name as HostClub,c2.name as GuestClub,m.start_time as StartTime,m.end_time as EndTime,s.name as Stadium,s.location as Location,t.ID as TicketID from Match m,Ticket t,TicketBuyingTransaction tbt,Fan f,Club c1,Club c2,Stadium s\r\nwhere m.match_ID=t.match_ID and t.ID=tbt.ticket_ID and t.status=0 and tbt.fan_nationalID='"+FANID+"' \r\nand m.host_club_ID=c1.club_ID and m.guest_club_ID=c2.club_ID and m.stadium_ID=s.ID\r\norder by m.start_time";
            SqlDataAdapter fansqlDA= new SqlDataAdapter(query,connection);
            DataTable fanDT = new DataTable();
            fansqlDA.Fill(fanDT);

            if(fanDT.Rows.Count > 0)
            {
                fanupcomingGrid.DataSource = fanDT;
                fanupcomingGrid.DataBind();
                fanupcomingLabel.Text = "";
            }
            else
            {
                fanupcomingGrid.DataSource = "";
                fanupcomingGrid.DataBind();
                fanupcomingLabel.Text = "No Tickets Purchased by this fan";
            }

            connection.Close();
        }
    }
}