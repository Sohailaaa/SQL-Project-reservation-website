﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml.Linq;

namespace M3horizon
{
    public partial class clubrep : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //Response.Write("Welcome Representative: " + Session["currentuser"]);
            cid5.Text = "Representative username: "+ Session["currentuser"];
            Viewclubdata(sender,e);
        }

        protected void Viewclubdata(object sender, EventArgs e)
        {
            String cruser = (String)Session["currentuser"];
            //String cruser = "fakeuser";

            String connstr = WebConfigurationManager.ConnectionStrings["mydatabase"].ToString();
            SqlConnection connection = new SqlConnection(connstr);

            String query = "select club_ID from ClubRepresentative where username='"+cruser+"'";
            SqlCommand cmd = new SqlCommand(query, connection);
            connection.Open();
            var c = (cmd.ExecuteScalar().ToString());
            cid.Text = c.ToString();

            int theclubid = Int16.Parse(c.ToString());
            String q2 = "Select name from Club where club_ID= '" + theclubid + "'";
            String q3 = "Select location from Club where club_ID= '" + theclubid + "'";
            SqlCommand cmd2 = new SqlCommand(q2, connection);
            SqlCommand cmd3 = new SqlCommand(q3, connection);

            cname.Text = (String)cmd2.ExecuteScalar();
            cloc.Text = (String)cmd3.ExecuteScalar();
            String strcname = (String)cmd2.ExecuteScalar();
            connection.Close();
            Viewupcoming(strcname);
        }

        protected void Viewupcoming(String club1name)
        {
            //upcomingMatchesOfClub
            String connstr = WebConfigurationManager.ConnectionStrings["mydatabase"].ToString();
            SqlConnection connection = new SqlConnection(connstr);

            SqlCommand upcoming = new SqlCommand("select * from upcomingMatchesOfClub(@club_name) order by StartTime", connection);
            upcoming.Parameters.Add(new SqlParameter("@club_name", club1name));
            connection.Open();
            SqlDataAdapter sqlda = new SqlDataAdapter(upcoming);
            DataTable tab = new DataTable();
            sqlda.Fill(tab);
            upcominggrid.DataSource = tab;
            upcominggrid.DataBind();
            connection.Close(); //viewAvailableStadiumsOn
        }

        protected void Viewstad(object sender, EventArgs e)
        {
            String datestadium = yyyy.Text + "-" + mm.Text + "-" + dd.Text + " " + hour.Text + ":" + min.Text;
            String connstr = WebConfigurationManager.ConnectionStrings["mydatabase"].ToString();
            SqlConnection connection = new SqlConnection(connstr);
            DateTime stadiumDateTime;

            if (!DateTime.TryParse(datestadium, out stadiumDateTime))
            {
                Label6.Text = "Invalid Date or Time, please try again";
                dategridst.DataSource = "";
                dategridst.DataBind();
            }
            else
            {
                Label6.Text = "";

                SqlCommand availablestad = new SqlCommand("select * from dbo.viewAvailableStadiumsOn(@ctime)", connection);
                availablestad.Parameters.Add(new SqlParameter("@ctime", stadiumDateTime));
                connection.Open();
                SqlDataAdapter sqlda = new SqlDataAdapter(availablestad);
                DataTable tab = new DataTable();
                sqlda.Fill(tab);
                dategridst.DataSource = tab;
                dategridst.DataBind();
                connection.Close();
            }
        }

        protected void Attemptrequest(object sender, EventArgs e)
        {
            //addHostRequest
            String cruser = (String)Session["currentuser"];
            string stadname = sname.Text;
            String stadtime = syyyy.Text + "-" + smm.Text + "-" + sdd.Text + " " + shour.Text + ":" + smin.Text;
            Boolean flag = true;

            DateTime startDateTime;

            if (stadtime == "-- :")
            {
                Label7.Text = "Invalid Date or Time, please try again";
                flag = false;
            }
            else { Label7.Text = ""; }

            if (!DateTime.TryParse(stadtime, out startDateTime) && stadtime != "-- :")
            {
                Label7.Text = "Invalid Date or Time, please try again";
                flag = false;
            }
            else { Label7.Text = ""; }

            if (stadname == "")
            {
                Label8.Text = "Please enter a Stadium name";
                flag = false;
            }
            else
            {
                String connstr = WebConfigurationManager.ConnectionStrings["mydatabase"].ToString();
                SqlConnection connection = new SqlConnection(connstr);
                connection.Open();
                String stadquery = "select name from Stadium where name='" + stadname + "' ";
                SqlDataAdapter sqldata = new SqlDataAdapter(stadquery, connection);

                DataTable dt = new DataTable();
                sqldata.Fill(dt);

                if (dt.Rows.Count == 0)
                {
                    Label8.Text = "This Stadium does not exist";
                    flag = false;
                }
                else { Label8.Text = ""; }
                connection.Close();
            }



            if (flag == true && stadname != "")
            {

                String connstr = WebConfigurationManager.ConnectionStrings["mydatabase"].ToString();
                SqlConnection connection = new SqlConnection(connstr);

                String q1 = "Select club_ID from ClubRepresentative where username= '" + cruser + "'";
                SqlCommand cmd = new SqlCommand(q1, connection);
                connection.Open();
                var c = (String)(cmd.ExecuteScalar().ToString());
                cid.Text = c.ToString();
                int theclubid = Int16.Parse(c.ToString());
                String q2 = "Select name from Club where club_ID= '" + theclubid + "'";
                SqlCommand cmd2 = new SqlCommand(q2, connection);
                String strcname = (String)cmd2.ExecuteScalar();

                ///match starttime and host to existing match 
                ///
                if (flag == true)
                {
                    //checking # of rows before adding HostRequest
                    String queryBefore = "select match_ID from HostRequest";
                    SqlDataAdapter beforeDA = new SqlDataAdapter(queryBefore, connection);  
                    DataTable beforeDT = new DataTable();
                    beforeDA.Fill(beforeDT);


                    SqlCommand addreq = new SqlCommand("addHostRequest", connection);
                    addreq.CommandType = CommandType.StoredProcedure;

                    addreq.Parameters.Add(new SqlParameter("@clubname", strcname));
                    addreq.Parameters.Add(new SqlParameter("@stadiumname", stadname));
                    addreq.Parameters.Add(new SqlParameter("@starttime", startDateTime));
                    addreq.ExecuteNonQuery();

                    //checking # of rows after adding HostRequest
                    String queryAfter = "select match_ID from HostRequest";
                    SqlDataAdapter afterDA = new SqlDataAdapter(queryAfter, connection);
                    DataTable afterDT = new DataTable();
                    afterDA.Fill(afterDT);
                    if(afterDT.Rows.Count > beforeDT.Rows.Count)
                    {
                        Label8.Text= "Request Successfully added";
                    }
                    else
                    {
                        Label8.Text = "No match at that time exists so no Hosting Request can be sent";
                    }
                }
                else
                {
                    if(Label8.Text == "")
                        Label8.Text = "Request Failed as your input data is invalid";
                }

                connection.Close();
                
            }
        }
    }
}