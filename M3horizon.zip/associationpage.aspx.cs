﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Collections;

namespace M3horizon
{
    public partial class associationpage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            welcomeLabel.Text = "Welcome: " + Session["currentuser"];

            Upcoming();
            Previous();
            Never();
        }

        protected void Add(object sender, EventArgs e)
        {
            String hostname = host.Text;
            String guestname = guest.Text;
            String starttime = syyyy.Text + "-" + smm.Text + "-" + sdd.Text + " " + shour.Text + ":" + smin.Text;
            String endtime   = eyyyy.Text + "-" + emm.Text + "-" + edd.Text + " " + ehour.Text + ":" + emin.Text;

            Boolean flag = true;
            DateTime startDateTime;
            DateTime endDateTime;

            if (hostname == guestname && hostname != "" && guestname != "")
            {
                Label10.Text = "Both clubs cannot be the same";
                flag = false;
            }
            else { Label10.Text = ""; }

            if (starttime == "-- :")
            {
                flag = false;
            }
            if (endtime == "-- :")
            {
                flag = false;
            }
            if (!DateTime.TryParse(starttime, out startDateTime) && starttime != "-- :")
            {
                Label6.Text = "This is an invalid date or time";
                flag = false;
            }
            else { Label6.Text = ""; }

            if (!DateTime.TryParse(endtime, out endDateTime) && endtime != "-- :")
            {
                Label7.Text = "This is an invalid date or time";
                flag = false;
            }
            else { Label7.Text = ""; }

            if (hostname == "" || guestname == "" || starttime == "" || endtime == "")
            {
                Label5.Text = "Please enter the missing data";
                flag = false;
            }
            ///////validate if clubs exist or not
            String connstr = WebConfigurationManager.ConnectionStrings["mydatabase"].ToString();
            SqlConnection connection = new SqlConnection(connstr);

            connection.Open();  //open connection

            SqlDataAdapter DAhost = new SqlDataAdapter("select name from Club where name = '" + hostname + "'", connection);
            DataTable tablehost = new DataTable();
            DAhost.Fill(tablehost);
            if (tablehost.Rows.Count == 0 && hostname != "")
            {
                Label8.Text = "This club does not exist";
                flag = false;
            }
            else { Label8.Text = ""; }

            SqlDataAdapter DAguest = new SqlDataAdapter("select name from Club where name = '" + guestname + "' ", connection);
            DataTable tableguest = new DataTable();
            DAguest.Fill(tableguest);
            if (tableguest.Rows.Count == 0 && guestname != "")
            {
                Label9.Text = "This club does not exist";
                flag = false;
            }
            else { Label9.Text = ""; }

            connection.Close();  //close connection
            //////

            if (flag==true)
            {

                SqlCommand addthismatch = new SqlCommand("addNewMatch", connection);
                addthismatch.CommandType = CommandType.StoredProcedure;


                addthismatch.Parameters.Add(new SqlParameter("@host_club", hostname));
                addthismatch.Parameters.Add(new SqlParameter("@guest_club", guestname));
                addthismatch.Parameters.Add(new SqlParameter("@start_time", startDateTime));
                addthismatch.Parameters.Add(new SqlParameter("@end_time", endDateTime));

                connection.Open();
                addthismatch.ExecuteNonQuery();
                connection.Close();
                Label5.Text = "Match Added Successfully";

                Upcoming();
                Previous();
                Never();
            }

        }

        protected void Delete(object sender, EventArgs e)
        {
            String hostname = host.Text;
            String guestname = guest.Text;
            String starttime = syyyy.Text + "-" + smm.Text + "-" + sdd.Text + " " + shour.Text + ":" + smin.Text;
            String endtime = eyyyy.Text + "-" + emm.Text + "-" + edd.Text + " " + ehour.Text + ":" + emin.Text;

            Boolean flag = true;
            DateTime startDateTime;
            DateTime endDateTime;

            if (hostname == guestname && hostname != "" && guestname != "")
            {
                Label10.Text = "Both clubs cannot be the same";
                flag = false;
            }
            else { Label10.Text = ""; }

            if (starttime == "-- :")
            {
                flag = false;
            }
            if (endtime == "-- :")
            {
                flag = false;
            }
            if (!DateTime.TryParse(starttime, out startDateTime) && starttime != "-- :")
            {
                Label6.Text = "This is an invalid date or time";
                flag = false;
            }
            else { Label6.Text = ""; }

            if (!DateTime.TryParse(endtime, out endDateTime) && endtime != "-- :")
            {
                Label7.Text = "This is an invalid date or time";
                flag = false;
            }
            else { Label7.Text = ""; }

            if (hostname == "" || guestname == "" || starttime == "" || endtime == "")
            {
                Label5.Text = "Please enter the missing data";
                flag = false;
            }
            ///////validate if clubs exist or not
            String connstr = WebConfigurationManager.ConnectionStrings["mydatabase"].ToString();
            SqlConnection connection = new SqlConnection(connstr);

            connection.Open();  //open connection

            SqlDataAdapter DAhost = new SqlDataAdapter("select name from Club where name = '" + hostname + "'", connection);
            DataTable tablehost = new DataTable();
            DAhost.Fill(tablehost);
            if (tablehost.Rows.Count == 0 && hostname != "")
            {
                Label8.Text = "This club does not exist";
                flag = false;
            }
            else { Label8.Text = ""; }

            SqlDataAdapter DAguest = new SqlDataAdapter("select name from Club where name = '" + guestname + "' ", connection);
            DataTable tableguest = new DataTable();
            DAguest.Fill(tableguest);
            if (tableguest.Rows.Count == 0 && guestname != "")
            {
                Label9.Text = "This club does not exist";
                flag = false;
            }
            else { Label9.Text = ""; }

            connection.Close();  //close connection
            //////


            if (flag==true)
            {

                SqlCommand deletethismatch = new SqlCommand("deletematchM3newProcedure", connection);
                deletethismatch.CommandType = CommandType.StoredProcedure;

                deletethismatch.Parameters.Add(new SqlParameter("@host_club", hostname));
                deletethismatch.Parameters.Add(new SqlParameter("@guest_club", guestname));
                deletethismatch.Parameters.Add(new SqlParameter("@start_time", startDateTime));
                deletethismatch.Parameters.Add(new SqlParameter("@end_time", endDateTime));

                connection.Open();
                deletethismatch.ExecuteNonQuery();
                connection.Close();
                Label5.Text = "Match DELETED Successfully";

                Upcoming();
                Previous();
                Never();
            }

        }

        protected void Upcoming()
        {
            String connstr = WebConfigurationManager.ConnectionStrings["mydatabase"].ToString();
            SqlConnection connection = new SqlConnection(connstr);
            connection.Open();
            String query = "select c1.name as HostClub,c2.name as GuestClub,m.start_time as StartTime,m.end_time as EndTime from Match m, Club c1, Club c2 where m.start_time>CURRENT_TIMESTAMP and m.host_club_ID=c1.club_ID and m.guest_club_ID=c2.club_ID order by m.start_time";
            SqlCommand up = new SqlCommand(query, connection);
            
            var reader = up.ExecuteReader();

            DataTable table = new DataTable();
            table.Load(reader);

            if (table.Rows.Count > 0)
            {
                upcominggrid.DataSource = table;
                upcominggrid.DataBind();
                upcomingLabel.Text = "";
            }
            else
            {
                upcominggrid.DataSource = "";
                upcominggrid.DataBind();
                upcomingLabel.Text = "No upcoming Matches exist yet";
            }
            
            connection.Close();

        }

        protected void Previous()
        {
            String connstr = WebConfigurationManager.ConnectionStrings["mydatabase"].ToString();
            SqlConnection connection = new SqlConnection(connstr);
            connection.Open();
            String query = "select c1.name as HostClub,c2.name as GuestClub,m.start_time as StartTime,m.end_time as EndTime from Match m, Club c1, Club c2 where m.end_time<CURRENT_TIMESTAMP and m.host_club_ID=c1.club_ID and m.guest_club_ID=c2.club_ID order by m.start_time";

            SqlCommand prev = new SqlCommand(query, connection);

            var reader = prev.ExecuteReader();

            DataTable table = new DataTable();
            table.Load(reader);

            if (table.Rows.Count > 0)
            {
                previousgrid.DataSource = table;
                previousgrid.DataBind();
                previousLabel.Text = "";
            }
            else
            {
                previousgrid.DataSource = "";
                previousgrid.DataBind();
                previousLabel.Text = "No Matches have already been played";
            }
            
            connection.Close();
        }

        protected void Never()
        {
            String connstr = WebConfigurationManager.ConnectionStrings["mydatabase"].ToString();
            SqlConnection connection = new SqlConnection(connstr);
            connection.Open();
            String query = "select c1.name as Club1,c2.name as Club2 from Club c1, Club c2 where c1.name<>c2.name and c1.club_ID>c2.club_ID EXCEPT select c1.name,c2.name from Match m, Club c1, Club c2 where ( (c1.club_ID=m.host_club_ID and c2.club_ID=m.guest_club_ID) or (c2.club_ID=m.host_club_ID and c1.club_ID=m.guest_club_ID))";

            SqlCommand prev = new SqlCommand(query, connection);

            var reader = prev.ExecuteReader();

            DataTable table = new DataTable();
            table.Load(reader);

            if (table.Rows.Count > 0)
            {
                nevergrid.DataSource = table;
                nevergrid.DataBind();
                neverLabel.Text = "";
            }
            else
            {
                nevergrid.DataSource = "";
                nevergrid.DataBind();
                neverLabel.Text = "All the clubs have competed against each other";
            }

            connection.Close();
        }
    }
}