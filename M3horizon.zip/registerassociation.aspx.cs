﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace M3horizon
{
    public partial class registerassociation : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Registersam(object sender, EventArgs e)
        {
            String name = rname.Text;
            String user = rusername.Text;
            String pass = rpassword.Text;
            Boolean flag = true;

            if (name == "" || user == "" || pass == "")
            {
                flag = false;
                Label5.Text = "Please enter the missing data";
            }
            else { Label5.Text = ""; }

            String connstr = WebConfigurationManager.ConnectionStrings["mydatabase"].ToString();
            SqlConnection connection = new SqlConnection(connstr);

            //ensuring this user is in the SystemUser and valid
            connection.Open();
            String query = "SELECT * FROM SystemUser WHERE username='" + user + "' ";
            SqlDataAdapter sqldata = new SqlDataAdapter(query, connection);

            DataTable data = new DataTable();
            sqldata.Fill(data);
            connection.Close();
            if (data.Rows.Count > 0)
            {
                Label4.Text = "Username already in use please choose another one";
            }
            else if(flag==true)
            { 
                //adding to database
                SqlCommand addassociationmngr = new SqlCommand("addAssociationManager", connection);
                addassociationmngr.CommandType = CommandType.StoredProcedure;

                addassociationmngr.Parameters.Add(new SqlParameter("@name", name));
                addassociationmngr.Parameters.Add(new SqlParameter("@username", user));
                addassociationmngr.Parameters.Add(new SqlParameter("@password", pass));

                connection.Open();
                addassociationmngr.ExecuteNonQuery();
                connection.Close();

                //redirecting
                Session["currentuser"] = user;
                Response.Redirect("associationpage.aspx");
            }


        }
    }
}