﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml.Linq;
using static System.Net.Mime.MediaTypeNames;

namespace M3horizon
{
    public partial class registerfan : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Registerfan(object sender, EventArgs e)
        {
            String nameoffan = name.Text;
            String user = username.Text;
            String pass = password.Text;
            String national = natidnumber.Text;
            String phone = phonenumber.Text;
            String birthdatefan = yyyy.Text + "-" + mm.Text + "-" + dd.Text;
            String addressfan = address.Text;

            Boolean flag = true;
            if (nameoffan == "" || user == "" || pass == "" || national == "" || phone == "" || birthdatefan == "" || addressfan == "")
            {
                emptyornot.Text = "Please enter the missing data";
                flag = false;
            }
            else emptyornot.Text = "";

            ////////////////////////////////////////parse national phone birthdatefan(size 2 4)(value)
            DateTime birthdateDateTime;
            if (!DateTime.TryParse(birthdatefan, out birthdateDateTime) && birthdatefan!="--")
            {
                flag = false;
                dateflag.Text = "---------------->INVALID DATE";
            }
            else { dateflag.Text = "";  }

            var isNumeric4 = int.TryParse(national, out int natIDparsed); //national
            var isNumeric5 = int.TryParse(phone, out int phoneparsed); //phone


            String connstr = WebConfigurationManager.ConnectionStrings["mydatabase"].ToString();
            SqlConnection connection = new SqlConnection(connstr);
            connection.Open();


            if (!(isNumeric4) && national != "")
            {
                natflag.Text = "Please write the National ID as numbers only";
                flag = false;
            }
            else if(isNumeric4 && national != "")
            { 
                String que2 = "select national_ID from Fan where national_ID='"+ natIDparsed + "'";
                SqlDataAdapter sqlDA2 = new SqlDataAdapter(que2,connection);
                DataTable dt2 = new DataTable();
                sqlDA2.Fill(dt2);

                if(dt2.Rows.Count > 0)
                {
                    natflag.Text = "This national ID is already being used in another account";
                    flag = false;
                }
                else
                {
                    natflag.Text = "";
                }
            }
            else if(national == "")
            {
                natflag.Text = "";
            }



            if (!(isNumeric5) && phone != "")
            {
                phoneflag.Text = "Please write the Phone Number as numbers only";
                flag = false;
            }
            else { phoneflag.Text = ""; }



            //ensuring this user is NOT NOT NOT in the SystemUser
            String query = "SELECT * FROM SystemUser WHERE username='" + user + "' ";
            SqlDataAdapter sqldata = new SqlDataAdapter(query, connection);

            DataTable data = new DataTable();
            sqldata.Fill(data);
            connection.Close();


            if (data.Rows.Count > 0)
            {
                userflag.Text = "--------->Username already taken, please choose another one";
                flag = false;
            }
            else { userflag.Text = ""; }

            if (flag==true)
            {

                SqlCommand addnewfan = new SqlCommand("addFan", connection);
                addnewfan.CommandType = CommandType.StoredProcedure;

                addnewfan.Parameters.Add(new SqlParameter("@fan_name", nameoffan));
                addnewfan.Parameters.Add(new SqlParameter("@username", user));
                addnewfan.Parameters.Add(new SqlParameter("@password", pass));
                addnewfan.Parameters.Add(new SqlParameter("@fan_national_id", national));
                addnewfan.Parameters.Add(new SqlParameter("@fan_phone", phone));
                addnewfan.Parameters.Add(new SqlParameter("@fan_birthdate", birthdateDateTime));
                addnewfan.Parameters.Add(new SqlParameter("@fan_address", addressfan));

                connection.Open();
                addnewfan.ExecuteNonQuery();
                connection.Close();

                Session["currentuser"] = user;
                Response.Redirect("fan.aspx");
            }


        }
    }
}