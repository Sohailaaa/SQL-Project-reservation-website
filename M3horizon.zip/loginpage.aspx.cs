﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace M3horizon
{
    public partial class loginpage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            loginpass.TextMode = TextBoxMode.Password;
        }

        protected void Loginattempt(object sender, EventArgs e)
        {
            /*
            if (loginuser.Text=="admin" && loginpass.Text=="admin")
            {
                Session["currentuser"] = "admin";
                Response.Redirect("adminpage.aspx");
            }
            */
            if(loginuser.Text == "" || loginpass.Text == "")
            {
                Label4.Text = "Please enter your username and password";
            }
            else
            {
                String user = loginuser.Text;
                String pass = loginpass.Text;

                String connstr = WebConfigurationManager.ConnectionStrings["mydatabase"].ToString();
                SqlConnection connection = new SqlConnection(connstr);

               //ensuring this user is in the SystemUser and valid
                String query = "SELECT * FROM SystemUser WHERE username='"+user+"' AND password='"+pass+"' ";
                SqlDataAdapter sqldata = new SqlDataAdapter(query, connection);
            
                DataTable data= new DataTable();
                sqldata.Fill(data);

                if(data.Rows.Count > 0)
                {
                    Session["currentuser"] = user;

                    //case SYSTEM ADMIN
                    String adminquery = "SELECT * FROM SystemAdmin WHERE username= '"+user+"' ";
                    SqlDataAdapter admindata = new SqlDataAdapter(adminquery, connection);
                    DataTable tableadmin = new DataTable();
                    admindata.Fill(tableadmin);
                    if (tableadmin.Rows.Count > 0)
                    {
                        Response.Redirect("adminpage.aspx");
                    }

                    //case Sports Association Manager
                    String assocquery = "SELECT * FROM AssociationManager WHERE username= '" + user + "' ";
                    SqlDataAdapter assocdata = new SqlDataAdapter(assocquery, connection);
                    DataTable tableassoc = new DataTable();
                    assocdata.Fill(tableassoc);
                    if (tableassoc.Rows.Count > 0)
                    {
                        Response.Redirect("associationpage.aspx");
                    }

                    //case Club Representative
                    String repquery = "SELECT * FROM ClubRepresentative WHERE username= '" + user + "' ";
                    SqlDataAdapter repdata = new SqlDataAdapter(repquery, connection);
                    DataTable tablerep = new DataTable();
                    repdata.Fill(tablerep);
                    if (tablerep.Rows.Count > 0)
                    {
                        Response.Redirect("clubrep.aspx");
                    }

                    //case Stadium Manager
                    String manquery = "SELECT * FROM StadiumManager WHERE username= '" + user + "' ";
                    SqlDataAdapter mandata = new SqlDataAdapter(manquery, connection);
                    DataTable tableman = new DataTable();
                    mandata.Fill(tableman);
                    if (tableman.Rows.Count > 0)
                    {
                        Response.Redirect("manager.aspx");
                    }

                    //case FAN
                    String fanquery = "SELECT * FROM Fan WHERE username= '" + user + "' ";
                    SqlDataAdapter fandata = new SqlDataAdapter(fanquery, connection);
                    DataTable tablefan = new DataTable();
                    fandata.Fill(tablefan);
                    if (tablefan.Rows.Count > 0)
                    {
                        Response.Redirect("fan.aspx");
                    }

                }
                else
                {
                    Label4.Text = "INVALID CREDENTIALS"; //if not found in system user then invalid
                }

                /*redirect depending on what the user is to
                 * 1.System Admin 
                 * 2.Sports Association Manager
                 * 3.Club Representative
                 * 4.Stadium Manager
                 * 5.Fan
                 */
            }
        }

        protected void RegisterRedirect(object sender, EventArgs e)
        {
            Response.Redirect("registrationpage.aspx");
        }

        protected void Showpass(object sender, EventArgs e)
        {
            loginpass.TextMode = TextBoxMode.SingleLine;
        }

    }
}