﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace M3horizon
{
    public partial class registrationpage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Sportsassociationmanager(object sender, EventArgs e)
        {
            Response.Redirect("registerassociation.aspx");
        }

        protected void Clubrepresentative(object sender, EventArgs e)
        {
            Response.Redirect("registerclubrep.aspx");
        }

        protected void Stadiummanager(object sender, EventArgs e)
        {
            Response.Redirect("registerstadiummanager.aspx");
        }

        protected void Fan(object sender, EventArgs e)
        {
            Response.Redirect("registerfan.aspx");
        }
    }
}