﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace M3horizon
{
    public partial class manager : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //Response.Write("Welcome: " + Session["currentuser"]);

            String mngrusername = (string)Session["currentuser"];

            smusernamelab.Text = "Manager Username: "+mngrusername;
            //String mngrusername = "achiever2002";
            //String mngrusername = "nmoemen";


            String connstr = WebConfigurationManager.ConnectionStrings["mydatabase"].ToString();
            SqlConnection connection = new SqlConnection(connstr);
            connection.Open();

            String q1 = "select Stadium_ID from StadiumManager where username= '" + mngrusername + "'";
            SqlCommand cmd1 = new SqlCommand(q1, connection);

            String c = (String)(cmd1.ExecuteScalar().ToString());
            int thestadiumID = Int16.Parse(c.ToString());

            //calling to show all matches happening on this stadium
            MatchesonStadium(thestadiumID);

            String q2 = "select name from Stadium where ID= '" + thestadiumID + "'";
            SqlCommand cmd2 = new SqlCommand(q2, connection);

            String q3 = "select location from Stadium where ID= '" + thestadiumID + "'";
            SqlCommand cmd3 = new SqlCommand(q3, connection);

            String q4 = "select capacity from Stadium where ID= '" + thestadiumID + "'";
            SqlCommand cmd4 = new SqlCommand(q4, connection);

            String q5 = "select status from Stadium where ID= '" + thestadiumID + "'";
            SqlCommand cmd5 = new SqlCommand(q5, connection);

            sid.Text = "ID: "+c;
            sname.Text = "Name: "+(String)cmd2.ExecuteScalar();
            slocation.Text = "Location: " + (String)cmd3.ExecuteScalar();
            scapacity.Text = "Capacity: " + (String)(cmd4.ExecuteScalar().ToString());
            sstatus.Text = "Active Status: " + (String)(cmd5.ExecuteScalar().ToString());

            //String q6 = "select * from dbo.allPendingRequests(@smname varchar(20))";
            String queryHR = "select hr.ID as Request_ID, cr.name as Representative_Name, c1.name as HostClub, c2.name as GuestClub, m.start_time as StartTime, m.end_time as EndTime, hr.status as Status\r\nfrom HostRequest hr, StadiumManager sm, ClubRepresentative cr, Club c1, Club c2, Match m\r\nwhere '" + mngrusername + "'=sm.username and hr.manager_ID=sm.ID and hr.repersentative_ID=cr.ID\r\n\tand m.match_ID=hr.match_ID and m.host_club_ID=cr.club_ID and m.host_club_ID=c1.club_ID and m.guest_club_ID=c2.club_ID";
            SqlCommand pending = new SqlCommand(queryHR, connection);
            //pending.Parameters.AddWithValue("@smname", mngrusername);
            SqlDataAdapter pendingDA = new SqlDataAdapter(pending);
            DataTable pendingTable = new DataTable();
            pendingDA.Fill(pendingTable);
            if(pendingTable.Rows.Count > 0)
            {
                gridPending.DataSource = pendingTable;
                gridPending.DataBind();
                pendingtext.Text = "";
            }
            else
            {
                gridPending.DataSource = "";
                gridPending.DataBind();
                pendingtext.Text = "No requests at the moment";
            }
            connection.Close();
        }

        protected void AcceptRequest(object sender, EventArgs e)
        {
            String mngrusername = (string)Session["currentuser"];
            //String mngrusername = "achiever2002";
            //String mngrusername = "nmoemen";

            String connstr = WebConfigurationManager.ConnectionStrings["mydatabase"].ToString();
            SqlConnection connection = new SqlConnection(connstr);
            connection.Open();

            String reqIDstring = inputRequestID.Text;
            int reqID;
            if(Int32.TryParse(reqIDstring, out reqID))
            {
            String acceptQuery = "select ID from HostRequest where ID = '"+reqID+ "' and status='unhandled' ";
            SqlCommand acceptCMD = new SqlCommand(acceptQuery,connection);
            SqlDataAdapter acceptDA = new SqlDataAdapter(acceptCMD);
            DataTable acceptDT = new DataTable();
            acceptDA.Fill(acceptDT);
                if (acceptDT.Rows.Count > 0)
                {

                    //Update the stadium_ID in the Match
                    SqlCommand stadIDCMD = new SqlCommand("select Stadium_ID from StadiumManager where username= '" + mngrusername + "'", connection);
                    String a = (String)(stadIDCMD.ExecuteScalar().ToString());
                    int thestadiumID = Int16.Parse(a.ToString());

                    SqlCommand matchIDCMD = new SqlCommand("select match_ID from HostRequest where ID= '" + reqID + "'", connection);
                    String b = (String)(matchIDCMD.ExecuteScalar().ToString());
                    int thematchID = Int16.Parse(b.ToString());

                    String updatematchquery = "UPDATE Match set stadium_ID='" + thestadiumID + "' where match_ID='" + thematchID + "' ";
                    SqlCommand UpdateStadiumIDinMatch = new SqlCommand(updatematchquery, connection);
                    UpdateStadiumIDinMatch.ExecuteNonQuery();

                    //accept the request in HostRequest
                    String UpdateStatusQuery = "UPDATE HostRequest set status='accepted' where ID = '" + reqID + "' and status='unhandled' ";
                    SqlCommand UpdateStatusCMD = new SqlCommand(UpdateStatusQuery, connection);
                    UpdateStatusCMD.ExecuteNonQuery();

                    //add tickets
                    //1.get stadium capacity 
                    String q2 = "select capacity from Stadium where ID= '" + thestadiumID + "'";
                    SqlCommand capacityCMD = new SqlCommand(q2, connection);
                    String capacitySTR = (String)(capacityCMD.ExecuteScalar().ToString());
                    int capacity = Int16.Parse(capacitySTR.ToString());
                    //2.addticket procedure depending on capacity
                    String qInsertTicket = "INSERT into Ticket values(1,"+thematchID+")";
                    SqlCommand insertTicket = new SqlCommand(qInsertTicket,connection);
                    int count = 0;
                    while (count<100) 
                    {
                        insertTicket.ExecuteNonQuery();
                        count++;
                        //added only 100 tickets instead of capacity because it is taking minutes to add 25000 tickets when I tried
                    }
                    //update display
                    validIDtext.Text = "Request Successfully ACCEPTED";
                }
                else
                {
                    validIDtext.Text = "This Request either does not exist or has already been handled";
                }
            }
            else
            {
                validIDtext.Text = "Please enter a valid ID number";
            }



            //updating the pending list after ACCEPT
            String queryHR = "select hr.ID as Request_ID, cr.name as Representative_Name, c1.name as HostClub, c2.name as GuestClub, m.start_time as StartTime, m.end_time as EndTime, hr.status as Status\r\nfrom HostRequest hr, StadiumManager sm, ClubRepresentative cr, Club c1, Club c2, Match m\r\nwhere '"+mngrusername+"'=sm.username and hr.manager_ID=sm.ID and hr.repersentative_ID=cr.ID\r\n\tand m.match_ID=hr.match_ID and m.host_club_ID=cr.club_ID and m.host_club_ID=c1.club_ID and m.guest_club_ID=c2.club_ID";
            SqlCommand pending = new SqlCommand(queryHR, connection);
            //pending.Parameters.AddWithValue("@smname", mngrusername);
            SqlDataAdapter pendingDA = new SqlDataAdapter(pending);
            DataTable pendingTable = new DataTable();
            pendingDA.Fill(pendingTable);
            if (pendingTable.Rows.Count > 0)
            {
                gridPending.DataSource = pendingTable;
                gridPending.DataBind();
                pendingtext.Text = "";
            }
            else
            {
                gridPending.DataSource = "";
                gridPending.DataBind();
                pendingtext.Text = "No requests at the moment";
            }

            String q1 = "select Stadium_ID from StadiumManager where username= '" + mngrusername + "'";
            SqlCommand cmd1 = new SqlCommand(q1, connection);

            String c = (String)(cmd1.ExecuteScalar().ToString());
            int sID = Int16.Parse(c.ToString());

            //calling to show all matches happening on this stadium
            MatchesonStadium(sID);

            connection.Close();
        }

        protected void RejectRequest(object sender, EventArgs e)
        {
            String mngrusername = (string)Session["currentuser"];
            //String mngrusername = "achiever2002";
            //String mngrusername = "nmoemen";

            String connstr = WebConfigurationManager.ConnectionStrings["mydatabase"].ToString();
            SqlConnection connection = new SqlConnection(connstr);
            connection.Open();

            String reqIDstring = inputRequestID.Text;
            int reqID;

            if (Int32.TryParse(reqIDstring, out reqID))
            {
                String acceptQuery = "select ID from HostRequest where ID = '" + reqID + "' and status='unhandled' ";
                SqlCommand acceptCMD = new SqlCommand(acceptQuery, connection);
                SqlDataAdapter acceptDA = new SqlDataAdapter(acceptCMD);
                DataTable acceptDT = new DataTable();
                acceptDA.Fill(acceptDT);
                if (acceptDT.Rows.Count > 0)
                {
                    //reject the request in HostRequest rejected
                    String UpdateStatusQuery = "UPDATE HostRequest set status='rejected' where ID = '" + reqID + "' and status='unhandled' ";
                    SqlCommand UpdateStatusCMD = new SqlCommand(UpdateStatusQuery, connection);
                    UpdateStatusCMD.ExecuteNonQuery();

                    //update display
                    validIDtext.Text = "Request Successfully REJECTED";
                }
                else
                {
                    validIDtext.Text = "This Request either does not exist or has already been handled";
                }
            }
            else
            {
                validIDtext.Text = "Please enter a valid ID number";
            }



            //updating the pending list after REJECT
            String queryHR = "select hr.ID as Request_ID, cr.name as Representative_Name, c1.name as HostClub, c2.name as GuestClub, m.start_time as StartTime, m.end_time as EndTime, hr.status as Status\r\nfrom HostRequest hr, StadiumManager sm, ClubRepresentative cr, Club c1, Club c2, Match m\r\nwhere '" + mngrusername + "'=sm.username and hr.manager_ID=sm.ID and hr.repersentative_ID=cr.ID\r\n\tand m.match_ID=hr.match_ID and m.host_club_ID=cr.club_ID and m.host_club_ID=c1.club_ID and m.guest_club_ID=c2.club_ID";
            SqlCommand pending = new SqlCommand(queryHR, connection);
            //pending.Parameters.AddWithValue("@smname", mngrusername);
            SqlDataAdapter pendingDA = new SqlDataAdapter(pending);
            DataTable pendingTable = new DataTable();
            pendingDA.Fill(pendingTable);
            if (pendingTable.Rows.Count > 0)
            {
                gridPending.DataSource = pendingTable;
                gridPending.DataBind();
                pendingtext.Text = "";
            }
            else
            {
                gridPending.DataSource = "";
                gridPending.DataBind();
                pendingtext.Text = "No requests at the moment";
            }


            String q1 = "select Stadium_ID from StadiumManager where username= '" + mngrusername + "'";
            SqlCommand cmd1 = new SqlCommand(q1, connection);

            String c = (String)(cmd1.ExecuteScalar().ToString());
            int sID = Int16.Parse(c.ToString());

            //calling to show all matches happening on this stadium
            MatchesonStadium(sID);
            connection.Close();
        }

        protected void MatchesonStadium(int stadiumID)
        {
            
            String connstr = WebConfigurationManager.ConnectionStrings["mydatabase"].ToString();
            SqlConnection connection = new SqlConnection(connstr);
            connection.Open();
            String query = "select c1.name as HostClub ,c2.name as GuestClub ,m.start_time as StartTime ,m.end_time as EndTime, s.name as Stadium from Match m,Club c1,Club c2,Stadium s where m.host_club_ID=c1.club_ID and m.guest_club_ID=c2.club_ID and m.stadium_ID=s.ID and s.ID='" + stadiumID+ "' order by m.start_time ";
            SqlDataAdapter data1adapt = new SqlDataAdapter(query,connection);
            DataTable dt = new DataTable();
            data1adapt.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                gridallMatches.DataSource = dt;
                gridallMatches.DataBind();
                Label2.Text = "";
            }
            else
            {
                gridallMatches.DataSource = "";
                gridallMatches.DataBind();
                Label2.Text = "No matches registered on this stadium at the moment";
            }
            connection.Close();

        }



    }
}