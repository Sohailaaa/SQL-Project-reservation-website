﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml.Linq;

namespace M3horizon
{
    public partial class registerclubrep : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Registercr(object sender, EventArgs e)
        {
            String name = rname.Text;
            String user = rusername.Text;
            String pass = rpassword.Text;
            String cname = clubname.Text;
            Boolean flag = true;

            String connstr = WebConfigurationManager.ConnectionStrings["mydatabase"].ToString();
            SqlConnection connection = new SqlConnection(connstr);
            connection.Open();

            //ensuring this user is new and unique
            String query = "SELECT * FROM SystemUser WHERE username='" + user + "' ";
            SqlDataAdapter sqldata = new SqlDataAdapter(query, connection);

            DataTable data = new DataTable();
            sqldata.Fill(data);
            connection.Close();

            if (name==""||user==""||pass=="")
            {
                Label7.Text = "Please write the missing data";
                flag = false;
            }
            else { Label7.Text = ""; }


            if (data.Rows.Count > 0)
            {
                Label5.Text = "Username already in use, please choose another username";
                flag = false;
            }
            else { Label5.Text = ""; }



            if (cname != "")
            {
                connection.Open();

                String q2 = "select club_ID from Club where name= '" + cname + "'";
                SqlCommand clubidcommand = new SqlCommand(q2, connection);
                SqlDataAdapter cidDA = new SqlDataAdapter(q2, connection);

                DataTable table1 = new DataTable();
                cidDA.Fill(table1);
                if (table1.Rows.Count==0)
                {
                    flag = false;
                    Label6.Text = "This club does not exist";
                }
                else
                {
                    int theclubid = Int16.Parse(clubidcommand.ExecuteScalar().ToString());

                    String q3 = "select * from ClubRepresentative where club_ID= '" + theclubid + "'";
                    SqlDataAdapter cid = new SqlDataAdapter(q3, connection);

                    DataTable table2 = new DataTable();
                    cid.Fill(table2);

                    if (table2.Rows.Count > 0)
                    {
                        flag = false;
                        Label6.Text = "This Club already has a representative, please choose another Club";
                    }
                    else { Label6.Text = ""; }
                }

                connection.Close();

            }

            //add to database and transition to next page
            if (flag == true)
            {
                //case unique username and club doesnt have a representative

                //adding to database
                SqlCommand addcr = new SqlCommand("addRepresentative", connection);
                addcr.CommandType = CommandType.StoredProcedure;

                addcr.Parameters.Add(new SqlParameter("@name", name));
                addcr.Parameters.Add(new SqlParameter("@clubname", cname));
                addcr.Parameters.Add(new SqlParameter("@username", user));
                addcr.Parameters.Add(new SqlParameter("@password", pass));

                connection.Open();
                addcr.ExecuteNonQuery();

                //redirecting
                connection.Close();
                Session["currentuser"] = user;
                Response.Write("added successfully");
                Response.Redirect("clubrep.aspx");
            }


        }
    }
}